# Playwright Automation Framework

This framework is designed for API testing using [Playwright](https://playwright.dev/), enabling robust, scalable, and efficient API test automation. It leverages Playwright's powerful API testing capabilities to validate various HTTP requests and responses.

## Features
- Supports GET, POST, PUT, and DELETE requests.
- Automated test script generation for Playwright.
- Dynamic test case generation from HAR files.
- Customizable request filtering for optimized testing.

## Download and Installation
1. **Download the Framework**
   - Click the **Download Framework** button to download the zip file containing the Playwright Automation Framework.
2. **Extract the Zip File**
   - Extract the downloaded zip file to your desired location.
3. **Install Dependencies**
   - Navigate to the project folder:
```bash
cd <project-folder>
```
   - Install required dependencies:
```bash
npm install
```

## Running Tests
To execute all tests:
```bash
npx playwright test
```

To run a specific test file:
```bash
npx playwright test tests/api/userTests.spec.ts
```

To generate an HTML report:
```bash
npx playwright show-report
```

## Generating Tests from HAR Files
The framework allows automated test generation from `.har` files via the UI. Follow these steps:
1. **Upload the HAR File**
   - Click the **Upload HAR File** button in the UI and select your `.har` file.
2. **Generate Test Code**
   - Click the **Generate Test Code** button to generate the Playwright test file.
3. The generated Playwright test file will be saved in the `Downloads` folder.
4. Move the generated test file to the `/tests/api` folder manually for execution.

## Best Practices
- Use environment variables for sensitive data.
- Maintain a clear folder structure with separate files for test data, utilities, and test logic.
- Regularly update Playwright dependencies for enhanced performance and security.


For additional guidance or questions, feel free to reach out!
