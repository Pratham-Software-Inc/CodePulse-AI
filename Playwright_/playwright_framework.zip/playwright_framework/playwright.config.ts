import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    extraHTTPHeaders: {
      'Content-Type': 'application/json'
    }
  }, 
  reporter: [['html', { outputFolder: 'playwright-report' }]]
});