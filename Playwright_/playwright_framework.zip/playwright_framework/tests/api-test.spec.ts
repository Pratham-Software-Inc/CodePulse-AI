import { test, expect } from '@playwright/test';

// sample tests
test('Validate Global Search API', async ({ request }) => {
  const response = await request.get('https://groww.in/v1/api/search/v3/query/global/st_p_query?page=0&query=&size=6&web=true', {
    headers: {
"accept": "application/json, text/plain, */*",
"x-app-id": "growwWeb",
"x-device-id": "bc7cc57b-8953-5ee3-9863-fbb7a88f325a",
"x-device-type": "desktop",
"x-platform": "web"
},
    data: undefined
  });

  expect(response.status()).toBe(200);
});

test('Validate Live Aggregated Data API', async ({ request }) => {
  const response = await request.post('https://groww.in/v1/api/stocks_data/v1/tr_live_delayed/segment/CASH/latest_aggregated', {
    headers: {
"accept": "application/json, text/plain, */*",
"content-type": "application/json",
"x-app-id": "growwWeb",
"x-device-id": "bc7cc57b-8953-5ee3-9863-fbb7a88f325a",
"x-device-type": "desktop",
"x-platform": "web"
},
    data: {"exchangeAggReqMap":{"NSE":{"priceSymbolList":["SHRIRAMFIN","CHOLAFIN","BAJAJHLDNG","BAJFINANCE","BAJAJFINSV","VBL","HAVELLS","ULTRACEMCO","BHEL","ABB","CREDITACC","AMBER","INOXINDIA","BHARTIHEXA","POLYCAB"],"indexSymbolList":[]},"BSE":{"priceSymbolList":[],"indexSymbolList":[]}}}
  });

  expect(response.status()).toBe(200);
});